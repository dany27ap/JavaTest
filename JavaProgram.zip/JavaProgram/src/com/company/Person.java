package com.company;

public class Person {
    public String helloWorld() {
        return "Hello World";
    }
}
